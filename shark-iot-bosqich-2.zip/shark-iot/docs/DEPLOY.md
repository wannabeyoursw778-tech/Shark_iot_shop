# Telefondan internetga joylash (bepul)

Kerak: GitHub akkaunt, Neon akkaunt (database), Render akkaunt (server).

## 1. Database — Neon (neon.tech)
1. neon.tech ga kiring, "Sign up" (Google bilan bo'ladi).
2. Yangi project yarating, nomi: `shark-iot`.
3. "Connection string" ni nusxalang (`postgresql://...` bilan boshlanadi). Buni Render'ga qo'yamiz.

## 2. Kodni GitHub'ga yuklash
1. github.com da yangi **private** repository yarating: `shark-iot`.
2. Zip ichidagi hamma narsani (backend, frontend, database papkalari, .env.example, README.md) yuklang.
   `.env` faylini va `node_modules` ni YUKLAMANG.

## 3. Server — Render (render.com)
1. New → Web Service → GitHub repo'ni tanlang.
2. Sozlamalar:
   - Root Directory: `backend`
   - Build Command: `npm install`
   - Start Command: `npm start`
3. Environment Variables (qiymatlar):
   - `DATABASE_URL` = Neon'dan nusxalagan matn
   - `JWT_SECRET` = 40+ belgili tasodifiy matn
   - `NODE_ENV` = `production`
   - `FRONTEND_URL` = Render bergan manzil (masalan https://shark-iot.onrender.com)
   - `ADMIN_USER` = admin login, `ADMIN_PASS` = parol (kamida 10 belgi)
   - `SEED_DEMO` = `true` (demo mahsulotlar uchun)
4. Deploy bosing. 3–5 daqiqadan keyin saytingiz tayyor.

## Muhim
- Bepul Render 15 daqiqa ishlatilmasa uxlaydi; birinchi ochilish 30–50 soniya olishi mumkin.
- Yuklangan mahsulot rasmlari Render bepul tarifida qayta ishga tushganda o'chib ketadi.
  Doimiy rasm saqlash (Cloudinary yoki Render Disk) 4-bosqichda ulanadi.
