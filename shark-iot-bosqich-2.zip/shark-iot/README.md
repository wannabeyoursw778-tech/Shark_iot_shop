# SHARK IoT — 2-bosqich: Web sayt + Buyurtma tizimi

Tayyor: web sayt (bosh sahifa, mahsulotlar, qidiruv/filtr, mahsulot sahifasi, savatcha, buyurtma), database, admin login, mahsulot API, buyurtmalar va qoldiq.
Keyingi bosqichlar: Telegram bot, admin panel ekrani, AI tavsif, review.

**Telefondan joylash:** `docs/DEPLOY.md` ni o'qing.

## Kerak bo'ladigan dasturlar
1. **Node.js 20+** — https://nodejs.org (LTS ni yuklang)
2. **PostgreSQL 14+** — https://www.postgresql.org/download

## O'rnatish (qadam-baqadam)

**1. Database yarating.** PostgreSQL o'rnatilgach terminalda:
```
psql -U postgres -c "CREATE DATABASE shark_iot"
```

**2. `.env` faylini yarating.** `.env.example` ni nusxalab, nomini `.env` qiling (loyiha asosiy papkasida):
```
cp .env.example .env
```
So'ng `.env` ni oching va ikkita narsani to'g'rilang:
- `DATABASE_URL` — parolni o'zingiznikiga almashtiring
- `JWT_SECRET` — bu buyruq bilan yarating va yopishtiring:
```
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

**3. Paketlarni o'rnating va jadvallarni yarating:**
```
cd backend
npm install
npm run db:setup
```
`db:setup` jadvallarni yaratadi va 9 ta **DEMO** mahsulot qo'shadi.

**4. Admin yarating:**
```
npm run admin:create
```
Login va parol (kamida 10 belgi) so'raladi.

**5. Serverni ishga tushiring:**
```
npm start
```
Sayt: brauzerda `http://localhost:4000` oching.

## API qisqacha
Ochiq: `GET /api/products` (`q, category, minPrice, maxPrice, inStock, sale, isNew, sort, page`), `GET /api/products/:slug`, `GET /api/categories`
Admin (`Authorization: Bearer TOKEN`): `POST /api/admin/login`, `GET/POST/PUT/DELETE /api/admin/products`, `POST /api/admin/products/:id/images`, `DELETE /api/admin/images/:id`

## Xavfsizlik (bu bosqichda)
Parol bcrypt bilan hashlanadi, JWT token, login uchun rate limit, barcha kirishlar zod bilan tekshiriladi, SQL so'rovlar parametrli (SQL injection yo'q), rasm faqat JPG/PNG/WEBP va 3 MB gacha, `.env` Git'ga tushmaydi.

## Demo mahsulotlarni o'chirish
Demo mahsulotlar `[DEMO]` deb belgilangan. Haqiqiy mahsulot qo'shgach, admin panel orqali (3-4 bosqich) o'chirasiz.
