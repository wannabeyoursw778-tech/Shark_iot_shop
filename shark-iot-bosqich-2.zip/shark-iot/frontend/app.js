(() => {
'use strict';
const CFG = {
  telegramChannel: 'https://t.me/shark_iot',
  telegramBot: 'https://t.me/shark_iot_bot',
  instagram1: 'https://instagram.com/jamshidbek_muxandis',
  instagram2: 'https://instagram.com/shark_iot',
};
const app = document.getElementById('app');
const toastEl = document.getElementById('toast');

/* ---------- yordamchi funksiyalar ---------- */
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + " so'm";
let toastT;
function toast(msg) {
  toastEl.textContent = msg; toastEl.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove('show'), 2200);
}
async function api(path, opts = {}) {
  let res, data;
  try {
    res = await fetch('/api' + path, { headers: { 'Content-Type': 'application/json' }, ...opts });
    data = await res.json();
  } catch { throw new Error('Internet yoki server bilan muammo. Qayta urinib ko\'ring.'); }
  if (!res.ok || !data.success) {
    const e = new Error(data.error || 'Xatolik yuz berdi'); e.details = data.details; throw e;
  }
  return data;
}
const setTitle = (t) => { document.title = t ? `${t} — SHARK IoT` : 'SHARK IoT — Arduino, ESP32, Robotics va Elektronika do\'koni'; };
const loading = () => { app.innerHTML = '<div class="loading"><span class="spin"></span>Yuklanmoqda…</div>'; };
const errorView = (msg) => {
  app.innerHTML = `<div class="empty"><p>😕 ${esc(msg)}</p><br><button class="btn" data-action="reload">Qayta urinish</button></div>`;
};
const PH = '<svg class="ph" viewBox="0 0 64 64" fill="none" stroke="#8b5cf6" stroke-width="3"><rect x="16" y="16" width="32" height="32" rx="4"/><path d="M24 8v8M32 8v8M40 8v8M24 48v8M32 48v8M40 48v8M8 24h8M8 32h8M8 40h8M48 24h8M48 32h8M48 40h8"/></svg>';

/* ---------- savatcha (brauzer xotirasida) ---------- */
const Cart = {
  get() { try { return JSON.parse(localStorage.getItem('shark_cart')) || []; } catch { return []; } },
  set(v) { try { localStorage.setItem('shark_cart', JSON.stringify(v)); } catch { /* ignore */ } Cart.badge(); },
  count() { return Cart.get().reduce((a, i) => a + i.qty, 0); },
  add(p, qty = 1) {
    const c = Cart.get(); const it = c.find((i) => i.id === p.id);
    const max = p.stock ?? 999;
    if (it) it.qty = Math.min(it.qty + qty, max); else c.push({ id: p.id, slug: p.slug, name: p.name, price: p.price, image: p.image || null, stock: p.stock, qty: Math.min(qty, max) });
    Cart.set(c);
  },
  setQty(id, qty) { const c = Cart.get(); const it = c.find((i) => i.id === id); if (it) it.qty = Math.max(1, Math.min(qty, it.stock || 999)); Cart.set(c); },
  remove(id) { Cart.set(Cart.get().filter((i) => i.id !== id)); },
  clear() { Cart.set([]); },
  badge() { const n = Cart.count(); const b = document.getElementById('cartCount'); b.textContent = n; b.hidden = n === 0; },
};

/* ---------- komponentlar ---------- */
function card(p) {
  const sale = p.old_price && p.old_price > p.price;
  const tag = !p.in_stock ? '<span class="tag out">Sotuvda yo\'q</span>' : sale ? `<span class="tag">-${Math.round((1 - p.price / p.old_price) * 100)}%</span>` : '';
  return `<article class="card">
    <a href="/products/${esc(p.slug)}" data-link class="card-img" aria-label="${esc(p.name)}">
      ${p.image ? `<img src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy" decoding="async">` : PH}${tag}${p.is_demo ? '<span class="tag demo">DEMO</span>' : ''}
    </a>
    <div class="card-body">
      <span class="card-cat">${esc(p.category || '')}</span>
      <a href="/products/${esc(p.slug)}" data-link class="card-title">${esc(p.name)}</a>
      <div><span class="price">${money(p.price)}</span>${sale ? `<span class="old">${money(p.old_price)}</span>` : ''}</div>
      <div class="card-foot">${p.in_stock
        ? `<button class="btn btn-primary btn-sm btn-block" data-action="add" data-id="${p.id}" data-slug="${esc(p.slug)}">🛒 Savatchaga</button>`
        : '<button class="btn btn-sm btn-block" disabled>❌ Sotuvda yo\'q</button>'}</div>
    </div></article>`;
}
const chipsFor = (cats, active) => `<div class="chips">${cats.map((c) =>
  `<a class="chip ${active === c.slug ? 'on' : ''}" href="/category/${esc(c.slug)}" data-link>${esc(c.name)}</a>`).join('')}</div>`;
let productCache = {};
const remember = (list) => list.forEach((p) => { productCache[p.id] = p; });

/* ---------- sahifalar ---------- */
async function pageHome() {
  setTitle(''); loading();
  const [cats, fresh, pop] = await Promise.all([api('/categories'), api('/products?sort=new&limit=4'), api('/products?sort=popular&limit=4')]);
  remember(fresh.data); remember(pop.data);
  app.innerHTML = `
  <section class="hero">
    <span class="eyebrow hero-glow">Robotics • IoT • Electronics</span>
    <h1>Robototexnika uchun kerakli texnologiyalar — bir joyda.</h1>
    <p>Arduino, ESP32, sensorlar va robot qismlari. O'zbekistonda loyihangizni tez va ishonchli boshlang.</p>
    <div class="hero-btns">
      <a class="btn btn-primary" href="/products" data-link>Mahsulotlarni ko'rish</a>
      <a class="btn" href="${CFG.telegramChannel}" target="_blank" rel="noopener">Telegram</a>
    </div>
    ${chipsFor(cats.data.filter((c) => c.product_count > 0), '')}
  </section>
  <section class="section"><div class="sec-head"><h2>Yangi mahsulotlar</h2><a class="muted" href="/products?sort=new" data-link>Hammasi →</a></div>
    <div class="grid">${fresh.data.map(card).join('')}</div></section>
  <section class="section"><div class="sec-head"><h2>Mashhur</h2><a class="muted" href="/products?sort=popular" data-link>Hammasi →</a></div>
    <div class="grid">${pop.data.map(card).join('')}</div></section>
  <section class="section"><div class="feature">
    <div class="box"><h3>🚚 Yetkazib berish</h3><p class="muted small">Gurlan shahri va tumani bo'yicha.</p></div>
    <div class="box"><h3>📲 Telegram orqali</h3><p class="muted small">Botdan ham buyurtma berish mumkin.</p></div>
    <div class="box"><h3>✅ Mavjudlik</h3><p class="muted small">Qoldiq real vaqtda yangilanadi.</p></div>
  </div></section>`;
}

async function pageProducts(categorySlug) {
  const sp = new URLSearchParams(location.search);
  const f = { q: sp.get('q') || '', category: categorySlug || sp.get('category') || '', minPrice: sp.get('minPrice') || '', maxPrice: sp.get('maxPrice') || '',
    inStock: sp.get('inStock') === '1', sale: sp.get('sale') === '1', isNew: sp.get('isNew') === '1', sort: sp.get('sort') || 'new', page: Number(sp.get('page')) || 1 };
  setTitle(categorySlug ? 'Kategoriya' : 'Mahsulotlar');
  if (!document.getElementById('plist')) {
    loading();
    const cats = (await api('/categories')).data;
    const sel = (v, t) => `<option value="${v}" ${f.sort === v ? 'selected' : ''}>${t}</option>`;
    app.innerHTML = `<h1 style="font-size:1.8rem;margin-bottom:14px">Mahsulotlar</h1>
    <form id="fform" class="filters" autocomplete="off">
      <input class="in f-search" name="q" type="search" placeholder="🔎 Qidirish: ESP32, sensor, servo…" value="${esc(f.q)}" enterkeyhint="search">
      <select class="in" name="category" aria-label="Kategoriya"><option value="">Barcha kategoriyalar</option>${cats.map((c) => `<option value="${esc(c.slug)}" ${f.category === c.slug ? 'selected' : ''}>${esc(c.name)} (${c.product_count})</option>`).join('')}</select>
      <select class="in" name="sort" aria-label="Saralash">${sel('new', 'Yangi')}${sel('popular', 'Mashhur')}${sel('price_asc', 'Arzon → qimmat')}${sel('price_desc', 'Qimmat → arzon')}</select>
      <input class="in" name="minPrice" type="number" inputmode="numeric" min="0" placeholder="Narx dan" value="${esc(f.minPrice)}">
      <input class="in" name="maxPrice" type="number" inputmode="numeric" min="0" placeholder="Narx gacha" value="${esc(f.maxPrice)}">
    </form>
    <div class="checks">
      <label class="chk"><input type="checkbox" name="inStock" form="fform" ${f.inStock ? 'checked' : ''}> Mavjud</label>
      <label class="chk"><input type="checkbox" name="isNew" form="fform" ${f.isNew ? 'checked' : ''}> Yangi</label>
      <label class="chk"><input type="checkbox" name="sale" form="fform" ${f.sale ? 'checked' : ''}> Chegirmada</label>
    </div><div id="plist"></div>`;
  }
  const box = document.getElementById('plist');
  box.innerHTML = '<div class="loading"><span class="spin"></span>Yuklanmoqda…</div>';
  const q = new URLSearchParams();
  if (f.q) q.set('q', f.q); if (f.category) q.set('category', f.category);
  if (f.minPrice) q.set('minPrice', f.minPrice); if (f.maxPrice) q.set('maxPrice', f.maxPrice);
  if (f.inStock) q.set('inStock', '1'); if (f.sale) q.set('sale', '1'); if (f.isNew) q.set('isNew', '1');
  q.set('sort', f.sort); q.set('page', f.page); q.set('limit', 12);
  try {
    const r = await api('/products?' + q);
    remember(r.data);
    const pg = r.pagination;
    box.innerHTML = r.data.length ? `<p class="muted small" style="margin-bottom:10px">Topildi: ${pg.total} ta</p><div class="grid">${r.data.map(card).join('')}</div>
      ${pg.pages > 1 ? `<div class="pager"><button class="btn btn-sm" data-page="${f.page - 1}" ${f.page <= 1 ? 'disabled' : ''}>← Oldingi</button><span class="muted">${f.page} / ${pg.pages}</span><button class="btn btn-sm" data-page="${f.page + 1}" ${f.page >= pg.pages ? 'disabled' : ''}>Keyingi →</button></div>` : ''}`
      : '<div class="empty">Hech narsa topilmadi 🔍<br><span class="small">Boshqa so\'z yoki filtr bilan urinib ko\'ring.</span></div>';
  } catch (e) { box.innerHTML = `<div class="empty">😕 ${esc(e.message)}</div>`; }
}

async function pageProduct(slug) {
  loading();
  const p = (await api('/products/' + encodeURIComponent(slug))).data;
  p.image = p.images[0]?.url || null; productCache[p.id] = p;
  setTitle(p.name);
  const sale = p.old_price && p.old_price > p.price;
  const specs = Object.entries(p.specs || {});
  app.innerHTML = `<div class="crumbs"><a href="/" data-link>Bosh sahifa</a> / <a href="/products" data-link>Mahsulotlar</a>${p.category ? ` / <a href="/category/${esc(p.category_slug)}" data-link>${esc(p.category)}</a>` : ''}</div>
  <div class="pdp">
    <div><div class="gal-main" id="galMain">${p.images[0] ? `<img src="${esc(p.images[0].url)}" alt="${esc(p.name)}" decoding="async">` : PH}</div>
      ${p.images.length > 1 ? `<div class="thumbs">${p.images.map((im, i) => `<button class="thumb ${i ? '' : 'on'}" data-img="${esc(im.url)}" aria-label="Rasm ${i + 1}"><img src="${esc(im.url)}" alt="" loading="lazy"></button>`).join('')}</div>` : ''}</div>
    <div>
      ${p.category ? `<span class="card-cat">${esc(p.category)}</span>` : ''}
      <h1 style="font-size:1.7rem;margin:4px 0">${esc(p.name)}</h1>
      <div class="muted small">SKU: ${esc(p.sku)} ${p.is_demo ? '· <span style="color:var(--warn)">DEMO mahsulot</span>' : ''}</div>
      <div class="pdp-price">${money(p.price)}${sale ? `<span class="old">${money(p.old_price)}</span>` : ''}</div>
      <div class="${p.in_stock ? 'stock-ok' : 'stock-no'}">${p.in_stock ? `✅ Mavjud (${p.stock} dona)` : '❌ Sotuvda yo\'q'}</div>
      <p class="muted" style="margin-top:12px">${esc(p.short_description)}</p>
      ${p.in_stock ? `<div class="buy">
        <div class="qty" id="pqty" data-max="${p.stock}"><button data-q="-1" aria-label="Kamaytirish">−</button><span id="pqv">1</span><button data-q="1" aria-label="Ko'paytirish">+</button></div>
        <button class="btn btn-primary" data-action="add-detail" data-id="${p.id}">🛒 Savatchaga qo'shish</button>
        <button class="btn" data-action="buy-now" data-id="${p.id}">⚡ Hozir buyurtma berish</button>
        <a class="btn btn-ghost" href="${CFG.telegramBot}?start=p_${p.id}" target="_blank" rel="noopener">📲 Telegram orqali buyurtma</a>
      </div>` : ''}
    </div>
  </div>
  ${p.description ? `<section class="section"><h2>Batafsil tavsif</h2><div class="box"><p style="white-space:pre-line">${esc(p.description)}</p></div></section>` : ''}
  ${specs.length ? `<section class="section"><h2>Texnik xususiyatlar</h2><div class="box"><table class="specs">${specs.map(([k, v]) => `<tr><td>${esc(k)}</td><td>${esc(v)}</td></tr>`).join('')}</table></div></section>` : ''}`;
}

async function pageCart() {
  setTitle('Savatcha'); loading();
  let items = Cart.get();
  // narx va qoldiqni serverdan yangilash
  const fresh = await Promise.all(items.map((i) => api('/products/' + encodeURIComponent(i.slug)).then((r) => r.data).catch(() => null)));
  items = items.map((it, k) => {
    const p = fresh[k]; if (!p || !p.in_stock) return null;
    return { ...it, price: p.price, stock: p.stock, name: p.name, image: p.images[0]?.url || null, qty: Math.min(it.qty, p.stock) };
  }).filter(Boolean);
  Cart.set(items);
  if (!items.length) { app.innerHTML = '<div class="empty"><div style="font-size:3rem">🛒</div><p>Savatchangiz bo\'sh</p><br><a class="btn btn-primary" href="/products" data-link>Mahsulotlarga o\'tish</a></div>'; return; }
  const total = items.reduce((a, i) => a + i.price * i.qty, 0);
  app.innerHTML = `<h1 style="font-size:1.8rem">Savatcha</h1>
  <div>${items.map((i) => `<div class="cart-row" data-row="${i.id}">
    <a href="/products/${esc(i.slug)}" data-link class="cart-img">${i.image ? `<img src="${esc(i.image)}" alt="" loading="lazy">` : PH}</a>
    <div class="cart-meta"><a href="/products/${esc(i.slug)}" data-link><b>${esc(i.name)}</b></a>
      <div class="muted small">${money(i.price)} × ${i.qty}</div>
      <div class="row"><div class="qty"><button data-cq="-1" data-id="${i.id}" aria-label="Kamaytirish">−</button><span>${i.qty}</span><button data-cq="1" data-id="${i.id}" aria-label="Ko'paytirish">+</button></div>
        <b>${money(i.price * i.qty)}</b><button class="link-del" data-action="del" data-id="${i.id}">🗑 O'chirish</button></div></div></div>`).join('')}</div>
  <div class="sum"><div class="row total"><span>Jami</span><span>${money(total)}</span></div>
    <p class="muted small">Yetkazib berish narxi keyingi qadamda hisoblanadi.</p>
    <a class="btn btn-primary btn-block" href="/checkout" data-link>Buyurtma berishga o'tish</a>
    <a class="btn btn-ghost btn-block" href="${CFG.telegramBot}" target="_blank" rel="noopener">📲 Telegram orqali buyurtma</a></div>`;
}

async function pageCheckout() {
  setTitle('Buyurtma berish');
  const items = Cart.get();
  if (!items.length) return navigate('/cart', true);
  loading();
  const st = (await api('/settings')).data;
  const sub = items.reduce((a, i) => a + i.price * i.qty, 0);
  const feeFor = (m) => (m === 'courier' && !(st.free_delivery_from > 0 && sub >= st.free_delivery_from) ? st.delivery_fee : 0);
  app.innerHTML = `<h1 style="font-size:1.8rem;margin-bottom:14px">Buyurtma berish</h1>
  <form id="oform" class="form" novalidate>
    <div id="oerr"></div>
    <div class="two"><div class="field"><label for="f_name">Ism *</label><input class="in" id="f_name" name="customer_name" autocomplete="name" required maxlength="100"></div>
      <div class="field"><label for="f_phone">Telefon raqam *</label><input class="in" id="f_phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+998 90 123 45 67" required></div></div>
    <div class="field"><label for="f_tg">Telegram username (ixtiyoriy)</label><input class="in" id="f_tg" name="telegram_username" placeholder="@username" autocapitalize="none"></div>
    <div class="two"><div class="field"><label for="f_reg">Viloyat *</label><select class="in" id="f_reg" name="region"><option>Xorazm</option></select></div>
      <div class="field"><label for="f_dis">Tuman/shahar *</label><select class="in" id="f_dis" name="district"><option>Gurlan shahri</option><option>Gurlan tumani</option></select></div></div>
    <div class="field"><label for="f_addr">Manzil *</label><input class="in" id="f_addr" name="address" autocomplete="street-address" placeholder="Ko'cha, uy raqami" required maxlength="300"></div>
    <div class="field"><label for="f_note">Izoh</label><textarea class="in" id="f_note" name="note" maxlength="500"></textarea></div>
    <div class="field"><label>Yetkazib berish usuli</label><div class="form" style="gap:8px">
      <label class="opt"><input type="radio" name="delivery_method" value="courier" checked><span>🚚 Yetkazib berish <span class="muted small">(${st.delivery_fee ? money(st.delivery_fee) : 'bepul'}${st.free_delivery_from ? `, ${money(st.free_delivery_from)} dan yuqori — bepul` : ''})</span></span></label>
      <label class="opt"><input type="radio" name="delivery_method" value="pickup"><span>🏪 O'zim olib ketaman <span class="muted small">(bepul)</span></span></label></div></div>
    <div class="field"><label>To'lov usuli</label><div class="form" style="gap:8px">
      <label class="opt"><input type="radio" name="payment_method" value="cod" checked><span>💵 Yetkazilganda to'lash</span></label>
      <label class="opt"><input type="radio" name="payment_method" value="cash"><span>💰 Naqd (do'konda)</span></label>
      <label class="opt dis"><input type="radio" disabled><span>Click <span class="muted small">(tez orada)</span></span></label>
      <label class="opt dis"><input type="radio" disabled><span>Payme <span class="muted small">(tez orada)</span></span></label></div></div>
    <div class="box sum" id="osum"></div>
    <button class="btn btn-primary btn-block" id="obtn" type="submit">Buyurtmani tasdiqlash</button>
  </form>`;
  const sum = () => {
    const m = app.querySelector('[name=delivery_method]:checked').value; const fee = feeFor(m);
    document.getElementById('osum').innerHTML = `${items.map((i) => `<div class="row"><span>${esc(i.name)} × ${i.qty}</span><span>${money(i.price * i.qty)}</span></div>`).join('')}
      <div class="row muted"><span>Yetkazib berish</span><span>${fee ? money(fee) : 'Bepul'}</span></div>
      <div class="row total"><span>Jami</span><span>${money(sub + fee)}</span></div>`;
  };
  sum();
  app.querySelectorAll('[name=delivery_method]').forEach((r) => r.addEventListener('change', sum));
  document.getElementById('oform').addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target); const btn = document.getElementById('obtn'); const eb = document.getElementById('oerr');
    const body = Object.fromEntries(fd.entries());
    body.items = Cart.get().map((i) => ({ product_id: i.id, quantity: i.qty }));
    btn.disabled = true; btn.textContent = 'Yuborilmoqda…'; eb.innerHTML = '';
    try {
      const r = await api('/orders', { method: 'POST', body: JSON.stringify(body) });
      Cart.clear(); sessionStorage.setItem('shark_last', JSON.stringify(r.data));
      navigate('/order-success');
    } catch (err) {
      eb.innerHTML = `<div class="err">${esc(err.message)}${err.details ? '<br><span class="small">' + err.details.map(esc).join('<br>') + '</span>' : ''}</div>`;
      eb.scrollIntoView({ behavior: 'smooth', block: 'center' });
      btn.disabled = false; btn.textContent = 'Buyurtmani tasdiqlash';
    }
  });
}

function pageSuccess() {
  setTitle('Buyurtma qabul qilindi');
  let o = null; try { o = JSON.parse(sessionStorage.getItem('shark_last')); } catch { /* ignore */ }
  if (!o) return navigate('/', true);
  app.innerHTML = `<div class="okbox"><div class="big">✅</div><h1 style="font-size:1.8rem;margin:8px 0">Buyurtma qabul qilindi!</h1>
    <p class="muted">Buyurtma raqami</p><p style="font-size:1.6rem;font-weight:800;color:var(--cyan)">${esc(o.order_code)}</p>
    <p style="margin:10px 0">Jami: <b>${money(o.total)}</b></p>
    <p class="muted small">Tez orada siz bilan bog'lanamiz.</p><br>
    <a class="btn btn-primary" href="/products" data-link>Xaridni davom ettirish</a></div>`;
}

function pageAbout() {
  setTitle('Biz haqimizda');
  app.innerHTML = `<h1 style="font-size:1.8rem;margin-bottom:12px">Biz haqimizda</h1><div class="box"><p>SHARK IoT — Arduino, ESP32, robototexnika va elektronika yo'nalishidagi onlayn do'kon. Maqsadimiz — talabalar, havaskorlar va muhandislar uchun sifatli komponentlarni qulay narxda yetkazish va bilim ulashish.</p>
  <p style="margin-top:10px" class="muted">Hozircha Xorazm viloyati, Gurlan shahri va tumani bo'yicha xizmat ko'rsatamiz.</p></div>`;
}
function pageContact() {
  setTitle('Aloqa');
  app.innerHTML = `<h1 style="font-size:1.8rem;margin-bottom:12px">Aloqa</h1><div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">
  <a class="box" href="${CFG.telegramChannel}" target="_blank" rel="noopener"><h3>✈️ Telegram kanal</h3><p class="muted small">@shark_iot</p></a>
  <a class="box" href="${CFG.telegramBot}" target="_blank" rel="noopener"><h3>🤖 Telegram bot</h3><p class="muted small">@shark_iot_bot</p></a>
  <a class="box" href="${CFG.instagram1}" target="_blank" rel="noopener"><h3>📸 Instagram</h3><p class="muted small">@jamshidbek_muxandis</p></a>
  <a class="box" href="${CFG.instagram2}" target="_blank" rel="noopener"><h3>📸 Instagram</h3><p class="muted small">@shark_iot</p></a></div>`;
}

/* ---------- router ---------- */
async function render() {
  document.getElementById('plist')?.remove();
  const path = location.pathname.replace(/\/+$/, '') || '/';
  document.querySelectorAll('.nav a').forEach((a) => a.classList.toggle('active', a.getAttribute('href') === path));
  let m;
  try {
    if (path === '/') await pageHome();
    else if (path === '/products') await pageProducts();
    else if ((m = path.match(/^\/category\/([\w-]+)$/))) await pageProducts(m[1]);
    else if ((m = path.match(/^\/products\/([\w-]+)$/))) await pageProduct(m[1]);
    else if (path === '/cart') await pageCart();
    else if (path === '/checkout') await pageCheckout();
    else if (path === '/order-success') pageSuccess();
    else if (path === '/about') pageAbout();
    else if (path === '/contact') pageContact();
    else app.innerHTML = '<div class="empty"><div style="font-size:3rem">404</div><p>Sahifa topilmadi</p><br><a class="btn" href="/" data-link>Bosh sahifa</a></div>';
  } catch (e) {
    if (e.message === 'Mahsulot topilmadi') app.innerHTML = '<div class="empty"><p>Mahsulot topilmadi 😕</p><br><a class="btn" href="/products" data-link>Mahsulotlar</a></div>';
    else errorView(e.message);
  }
}
function navigate(url, replace) {
  if (replace) history.replaceState({}, '', url); else history.pushState({}, '', url);
  window.scrollTo(0, 0); render();
}
const closeMenu = () => { document.getElementById('nav').classList.remove('open'); document.getElementById('menuBtn').setAttribute('aria-expanded', 'false'); };

/* ---------- hodisalar ---------- */
document.addEventListener('click', async (e) => {
  const a = e.target.closest('a[data-link]');
  if (a && !e.metaKey && !e.ctrlKey) { e.preventDefault(); closeMenu(); return navigate(a.getAttribute('href')); }
  const t = e.target.closest('[data-action],[data-page],[data-q],[data-cq],[data-img],#menuBtn');
  if (!t) return;
  if (t.id === 'menuBtn') { const n = document.getElementById('nav'); const o = n.classList.toggle('open'); t.setAttribute('aria-expanded', o); return; }
  if (t.dataset.page) { const sp = new URLSearchParams(location.search); sp.set('page', t.dataset.page); history.pushState({}, '', location.pathname + '?' + sp); window.scrollTo(0, 0); return pageProducts(location.pathname.startsWith('/category/') ? location.pathname.split('/')[2] : ''); }
  if (t.dataset.img) { document.getElementById('galMain').innerHTML = `<img src="${esc(t.dataset.img)}" alt="">`; document.querySelectorAll('.thumb').forEach((x) => x.classList.toggle('on', x === t)); return; }
  if (t.dataset.q) { const box = document.getElementById('pqty'); const v = document.getElementById('pqv'); v.textContent = Math.max(1, Math.min(Number(box.dataset.max), Number(v.textContent) + Number(t.dataset.q))); return; }
  if (t.dataset.cq) { const it = Cart.get().find((i) => i.id === Number(t.dataset.id)); if (it) { Cart.setQty(it.id, it.qty + Number(t.dataset.cq)); pageCart(); } return; }
  const act = t.dataset.action; const id = Number(t.dataset.id);
  if (act === 'reload') return render();
  if (act === 'add') { const p = productCache[id]; if (p) { Cart.add(p, 1); toast('✅ Savatchaga qo\'shildi'); } return; }
  if (act === 'add-detail' || act === 'buy-now') {
    const p = productCache[id]; const q = Number(document.getElementById('pqv').textContent) || 1;
    Cart.add(p, q); if (act === 'buy-now') return navigate('/checkout'); toast('✅ Savatchaga qo\'shildi'); return;
  }
  if (act === 'del') { Cart.remove(id); return pageCart(); }
});
// filtr formasi
let ft;
function applyFilters() {
  const fd = new FormData(document.getElementById('fform')); const sp = new URLSearchParams();
  for (const [k, v] of fd.entries()) if (v) sp.set(k, v === 'on' ? '1' : v);
  const catPage = location.pathname.startsWith('/category/');
  if (catPage) { const c = sp.get('category'); sp.delete('category'); history.replaceState({}, '', c ? `/category/${c}?${sp}` : `/products?${sp}`); }
  else history.replaceState({}, '', '/products' + (sp.toString() ? '?' + sp : ''));
  pageProducts(location.pathname.startsWith('/category/') ? location.pathname.split('/')[2] : '');
}
document.addEventListener('input', (e) => { if (e.target.closest('#fform') && e.target.type !== 'checkbox' && e.target.tagName !== 'SELECT') { clearTimeout(ft); ft = setTimeout(applyFilters, 350); } });
document.addEventListener('change', (e) => { if (e.target.closest('#fform') || e.target.form?.id === 'fform') applyFilters(); });
document.addEventListener('submit', (e) => { if (e.target.id === 'fform') e.preventDefault(); });
window.addEventListener('popstate', render);

Cart.badge(); render();
})();
