const express = require('express');
const { z } = require('zod');
const db = require('../db');
const { asyncH, validate } = require('../middleware');

const router = express.Router();
const STATUSES = ['new', 'accepted', 'preparing', 'delivering', 'delivered', 'cancelled'];

router.get('/', validate(z.object({
  status: z.enum(STATUSES).optional(),
  page: z.coerce.number().int().min(1).default(1),
}), 'query'), asyncH(async (req, res) => {
  const { status, page } = req.query;
  const params = [];
  let where = '';
  if (status) { params.push(status); where = 'WHERE o.status = $1'; }
  params.push(20, (page - 1) * 20);
  const { rows } = await db.query(
    `SELECT o.*, COALESCE(json_agg(json_build_object('name', i.product_name, 'price', i.price, 'quantity', i.quantity)
              ORDER BY i.id) FILTER (WHERE i.id IS NOT NULL), '[]') AS items
       FROM orders o LEFT JOIN order_items i ON i.order_id = o.id ${where}
      GROUP BY o.id ORDER BY o.id DESC LIMIT $${params.length - 1} OFFSET $${params.length}`, params);
  res.json({ success: true, data: rows });
}));

// Holatni o'zgartirish (bot ham shu funksiyadan foydalanadi). Bekor qilinsa qoldiq qaytariladi.
async function changeStatus(orderId, newStatus) {
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: [o] } = await client.query('SELECT id, status FROM orders WHERE id=$1 FOR UPDATE', [orderId]);
    if (!o) { await client.query('ROLLBACK'); return null; }
    if (o.status !== newStatus) {
      if (newStatus === 'cancelled') {
        await client.query(`UPDATE products p SET stock = p.stock + i.quantity, sold_count = GREATEST(p.sold_count - i.quantity, 0)
                              FROM order_items i WHERE i.order_id=$1 AND i.product_id = p.id`, [orderId]);
      } else if (o.status === 'cancelled') {
        // bekor qilingan buyurtmani qayta tiklash: qoldiq yetarli bo'lsa ayiramiz
        const chk = await client.query(`SELECT 1 FROM order_items i JOIN products p ON p.id=i.product_id
                                         WHERE i.order_id=$1 AND p.stock < i.quantity`, [orderId]);
        if (chk.rowCount) { await client.query('ROLLBACK'); const e = new Error('Qoldiq yetarli emas'); e.status = 409; throw e; }
        await client.query(`UPDATE products p SET stock = p.stock - i.quantity, sold_count = p.sold_count + i.quantity
                              FROM order_items i WHERE i.order_id=$1 AND i.product_id = p.id`, [orderId]);
      }
      await client.query('UPDATE orders SET status=$1, updated_at=now() WHERE id=$2', [newStatus, orderId]);
    }
    await client.query('COMMIT');
    return { id: orderId, status: newStatus };
  } catch (e) { await client.query('ROLLBACK').catch(() => {}); throw e; }
  finally { client.release(); }
}

router.patch('/:id(\\d+)/status', validate(z.object({ status: z.enum(STATUSES) })), asyncH(async (req, res) => {
  try {
    const r = await changeStatus(Number(req.params.id), req.body.status);
    if (!r) return res.status(404).json({ success: false, error: 'Buyurtma topilmadi' });
    res.json({ success: true, data: r });
  } catch (e) {
    if (e.status) return res.status(e.status).json({ success: false, error: e.message });
    throw e;
  }
}));

module.exports = router;
module.exports.changeStatus = changeStatus;
