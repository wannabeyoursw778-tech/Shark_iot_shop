const express = require('express');
const rateLimit = require('express-rate-limit');
const { z } = require('zod');
const db = require('../db');
const { asyncH, validate } = require('../middleware');

const router = express.Router();

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const orderSchema = z.object({
  items: z.array(z.object({
    product_id: z.number().int().positive(),
    quantity: z.number().int().min(1).max(100),
  })).min(1).max(30),
  customer_name: z.string().trim().min(2).max(100),
  phone: z.string().trim().regex(/^\+?[0-9\s()-]{9,20}$/, 'Telefon raqam noto\'g\'ri'),
  telegram_username: z.string().trim().regex(/^@?[A-Za-z0-9_]{3,32}$/, 'Telegram username noto\'g\'ri').optional().or(z.literal('')),
  region: z.string().trim().min(2).max(100),
  district: z.string().trim().min(2).max(100),
  address: z.string().trim().min(3).max(300),
  note: z.string().trim().max(500).optional().default(''),
  delivery_method: z.enum(['pickup', 'courier']),
  payment_method: z.enum(['cash', 'cod', 'click', 'payme']),
});

const orderLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, limit: 15,
  message: { success: false, error: 'Juda ko\'p buyurtma urinishi. Keyinroq qayta urinib ko\'ring.' },
});

async function getSettings() {
  const { rows } = await db.query('SELECT key, value FROM settings');
  const s = Object.fromEntries(rows.map((r) => [r.key, Number(r.value)]));
  return { delivery_fee: s.delivery_fee ?? 15000, free_delivery_from: s.free_delivery_from ?? 0 };
}

router.get('/settings', asyncH(async (req, res) => {
  res.json({ success: true, data: await getSettings() });
}));

router.post('/orders', orderLimiter, validate(orderSchema), asyncH(async (req, res, next) => {
  const b = req.body;
  if (['click', 'payme'].includes(b.payment_method)) {
    return res.status(400).json({ success: false, error: 'Click/Payme hali ulanmagan. Naqd yoki yetkazilganda to\'lashni tanlang.' });
  }
  // bir xil mahsulotni birlashtirish
  const qty = new Map();
  for (const i of b.items) qty.set(i.product_id, (qty.get(i.product_id) || 0) + i.quantity);
  const ids = [...qty.keys()];

  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const { rows: prods } = await client.query(
      'SELECT id, name, price, stock FROM products WHERE id = ANY($1) AND is_active ORDER BY id FOR UPDATE', [ids]);
    if (prods.length !== ids.length) throw new HttpError(400, 'Ba\'zi mahsulotlar topilmadi yoki sotuvdan olingan');

    let subtotal = 0;
    for (const p of prods) {
      const q = qty.get(p.id);
      if (p.stock < q) {
        throw new HttpError(409, p.stock === 0
          ? `"${p.name}" sotuvda qolmagan`
          : `"${p.name}" dan faqat ${p.stock} dona qoldi`);
      }
      subtotal += p.price * q;
    }
    const s = await getSettings();
    const fee = b.delivery_method === 'courier' && !(s.free_delivery_from > 0 && subtotal >= s.free_delivery_from) ? s.delivery_fee : 0;
    const total = subtotal + fee;

    const { rows: [o] } = await client.query(
      `INSERT INTO orders(customer_name, phone, telegram_username, region, district, address, note,
                          delivery_method, delivery_fee, payment_method, total)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id, created_at`,
      [b.customer_name, b.phone, (b.telegram_username || '').replace(/^@/, '') || null, b.region, b.district,
       b.address, b.note, b.delivery_method, fee, b.payment_method, total]);
    const code = 'SI-' + String(o.id).padStart(5, '0');
    await client.query('UPDATE orders SET order_code=$1 WHERE id=$2', [code, o.id]);

    for (const p of prods) {
      const q = qty.get(p.id);
      await client.query('INSERT INTO order_items(order_id, product_id, product_name, price, quantity) VALUES ($1,$2,$3,$4,$5)',
        [o.id, p.id, p.name, p.price, q]);
      await client.query('UPDATE products SET stock = stock - $1, sold_count = sold_count + $1 WHERE id = $2', [q, p.id]);
    }
    await client.query('INSERT INTO payments(order_id, method, amount) VALUES ($1,$2,$3)', [o.id, b.payment_method, total]);
    await client.query('COMMIT');

    // 3-bosqich: shu yerda Telegram admin'ga xabar yuboriladi
    res.status(201).json({ success: true, data: { order_code: code, total, delivery_fee: fee, status: 'new' } });
  } catch (e) {
    await client.query('ROLLBACK').catch(() => {});
    if (e instanceof HttpError) return res.status(e.status).json({ success: false, error: e.message });
    next(e);
  } finally { client.release(); }
}));

module.exports = router;
