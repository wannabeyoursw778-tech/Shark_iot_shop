const jwt = require('jsonwebtoken');
const config = require('./config');

// Token "Authorization: Bearer ..." sarlavhasida keladi (cookie emas) -> CSRF xavfi yo'q
function requireAdmin(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({ success: false, error: 'Kirish talab qilinadi' });
  try {
    const p = jwt.verify(token, config.jwtSecret);
    if (p.role !== 'admin') throw new Error('role');
    req.admin = p;
    next();
  } catch {
    res.status(401).json({ success: false, error: 'Token yaroqsiz yoki muddati tugagan' });
  }
}

const asyncH = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function validate(schema, source = 'body') {
  return (req, res, next) => {
    const r = schema.safeParse(req[source]);
    if (!r.success) {
      return res.status(400).json({
        success: false,
        error: 'Ma\'lumot noto\'g\'ri kiritilgan',
        details: r.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`),
      });
    }
    req[source] = r.data;
    next();
  };
}

module.exports = { requireAdmin, asyncH, validate };
