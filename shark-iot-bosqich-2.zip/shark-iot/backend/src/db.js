const { Pool } = require('pg');
const config = require('./config');

const pool = new Pool({
  connectionString: config.databaseUrl,
  ssl: config.isProd && !/localhost|127\.0\.0\.1/.test(config.databaseUrl)
    ? { rejectUnauthorized: false } : undefined,
});
pool.on('error', (e) => console.error('[DB] kutilmagan xato:', e.message));

module.exports = { query: (t, p) => pool.query(t, p), pool };
