const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const path = require('path');
const config = require('./config');
const db = require('./db');

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: { useDefaults: true, directives: { 'upgrade-insecure-requests': null } },
}));
app.use(cors({ origin: config.frontendUrl, methods: ['GET', 'POST', 'PUT', 'DELETE'] }));
app.use(express.json({ limit: '100kb' }));
app.use('/api', rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false,
  message: { success: false, error: 'Juda ko\'p so\'rov. Biroz kuting.' } }));

app.use('/uploads', express.static(path.join(__dirname, '../uploads'), { maxAge: '7d', index: false }));

app.get('/api/health', async (req, res) => {
  try { await db.query('SELECT 1'); res.json({ success: true, status: 'ok' }); }
  catch { res.status(503).json({ success: false, status: 'db_error' }); }
});
app.use('/api', require('./routes/public'));
app.use('/api', require('./routes/orders'));
app.use('/api/admin', require('./routes/admin'));

// Web sayt (frontend papkasi) — bitta server hamma narsani beradi
const siteDir = path.join(__dirname, '../../frontend');
app.use(express.static(siteDir, { maxAge: '1h', index: false }));

app.use('/api', (req, res) => res.status(404).json({ success: false, error: 'Yo\'l topilmadi' }));

// Toza URL'lar (/products/esp32-devkit va h.k.) uchun sayt qobig'i
app.get(/^\/(?!api\/|uploads\/).*/, (req, res) => res.sendFile(path.join(siteDir, 'index.html')));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(`[XATO] ${req.method} ${req.originalUrl}:`, err);
  if (err.type === 'entity.parse.failed') return res.status(400).json({ success: false, error: 'JSON noto\'g\'ri' });
  res.status(500).json({ success: false, error: 'Serverda xatolik. Keyinroq urinib ko\'ring.' });
});

if (require.main === module) {
  require('./bootstrap')()
    .then(() => app.listen(config.port, () => console.log(`SHARK IoT backend: http://localhost:${config.port}`)))
    .catch((e) => { console.error('Ishga tushirishda xato:', e.message); process.exit(1); });
}
module.exports = app;
