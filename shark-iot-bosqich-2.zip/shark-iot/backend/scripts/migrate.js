// Ishlatish: npm run db:setup   (jadvallar + demo mahsulotlar)
//            npm run db:migrate (faqat jadvallar)
const fs = require('fs');
const path = require('path');
require('../src/config');
const { pool } = require('../src/db');

(async () => {
  const dir = path.join(__dirname, '../../database');
  try {
    await pool.query(fs.readFileSync(path.join(dir, 'schema.sql'), 'utf8'));
    console.log('✅ Jadvallar tayyor');
    if (process.argv.includes('--seed')) {
      await pool.query(fs.readFileSync(path.join(dir, 'seed.sql'), 'utf8'));
      console.log('✅ Demo mahsulotlar qo\'shildi (DEMO deb belgilangan)');
    }
  } catch (e) {
    console.error('❌ Xato:', e.message);
    process.exitCode = 1;
  } finally { await pool.end(); }
})();
