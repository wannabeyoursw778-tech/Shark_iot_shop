// Ishlatish: npm run admin:create
const readline = require('readline');
const bcrypt = require('bcryptjs');
require('../src/config');
const { pool } = require('../src/db');

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((r) => rl.question(q, r));

(async () => {
  try {
    const username = (process.env.ADMIN_USER || await ask('Admin login (masalan: shark): ')).trim();
    const password = process.env.ADMIN_PASS || await ask('Parol (kamida 10 belgi): ');
    if (!/^[a-zA-Z0-9_.-]{3,50}$/.test(username)) throw new Error('Login 3–50 belgi: harf, raqam, _ . -');
    if (password.length < 10) throw new Error('Parol kamida 10 belgi bo\'lsin');
    const hash = await bcrypt.hash(password, 12);
    await pool.query(
      `INSERT INTO admins(username,password_hash) VALUES ($1,$2)
       ON CONFLICT (username) DO UPDATE SET password_hash = EXCLUDED.password_hash`, [username, hash]);
    console.log(`✅ Admin "${username}" tayyor`);
  } catch (e) { console.error('❌', e.message); process.exitCode = 1; }
  finally { rl.close(); await pool.end(); }
})();
