require('dotenv').config();

const required = ['DATABASE_URL', 'JWT_SECRET'];
for (const k of required) {
  if (!process.env[k]) {
    console.error(`XATO: .env faylida ${k} yozilmagan.`);
    process.exit(1);
  }
}
if (process.env.JWT_SECRET.length < 32) {
  console.error('XATO: JWT_SECRET kamida 32 belgi bo\'lishi kerak.');
  process.exit(1);
}

module.exports = {
  port: Number(process.env.PORT) || 4000,
  frontendUrl: (process.env.FRONTEND_URL || 'http://localhost:3000').split(','),
  databaseUrl: process.env.DATABASE_URL,
  jwtSecret: process.env.JWT_SECRET,
  isProd: process.env.NODE_ENV === 'production',
};
