// Server ishga tushganda: jadvallarni yaratadi, kerak bo'lsa demo mahsulot va admin qo'shadi.
// Bu telefondan joylashni osonlashtiradi (terminal kerak emas).
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const db = require('./db');

module.exports = async function bootstrap() {
  const dir = __dirname;
  await db.query(fs.readFileSync(path.join(dir, 'schema.sql'), 'utf8'));

  const { rows: [{ n }] } = await db.query('SELECT COUNT(*)::int AS n FROM products');
  if (process.env.SEED_DEMO === 'true' && n === 0) {
    await db.query(fs.readFileSync(path.join(dir, 'seed.sql'), 'utf8'));
    console.log('Demo mahsulotlar qo\'shildi');
  }

  const { ADMIN_USER, ADMIN_PASS } = process.env;
  if (ADMIN_USER && ADMIN_PASS) {
    if (ADMIN_PASS.length < 10) { console.warn('ADMIN_PASS kamida 10 belgi bo\'lishi kerak — admin yaratilmadi'); return; }
    const { rowCount } = await db.query('SELECT 1 FROM admins WHERE username=$1', [ADMIN_USER]);
    if (!rowCount) {
      await db.query('INSERT INTO admins(username,password_hash) VALUES ($1,$2)', [ADMIN_USER, await bcrypt.hash(ADMIN_PASS, 12)]);
      console.log(`Admin "${ADMIN_USER}" yaratildi`);
    }
  }
};
