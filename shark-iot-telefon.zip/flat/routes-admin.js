const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { z } = require('zod');
const db = require('./db');
const config = require('./config');
const { requireAdmin, asyncH, validate } = require('./middleware');

const router = express.Router();

// ---------- LOGIN (qattiq limit: 10 urinish / 15 daqiqa) ----------
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 10,
  message: { success: false, error: 'Juda ko\'p urinish. 15 daqiqadan keyin qayta urinib ko\'ring.' },
});
const DUMMY_HASH = bcrypt.hashSync('dummy-password', 12);

router.post('/login', loginLimiter,
  validate(z.object({ username: z.string().min(1).max(50), password: z.string().min(1).max(200) })),
  asyncH(async (req, res) => {
    const { username, password } = req.body;
    const { rows } = await db.query('SELECT id, username, password_hash FROM admins WHERE username = $1', [username]);
    const admin = rows[0];
    const ok = await bcrypt.compare(password, admin ? admin.password_hash : DUMMY_HASH);
    if (!admin || !ok) return res.status(401).json({ success: false, error: 'Login yoki parol noto\'g\'ri' });
    const token = jwt.sign({ sub: admin.id, username: admin.username, role: 'admin' }, config.jwtSecret, { expiresIn: '12h' });
    res.json({ success: true, data: { token, username: admin.username } });
  }));

// Quyidagi barcha yo'llar faqat admin uchun
router.use(requireAdmin);

router.get('/me', (req, res) => res.json({ success: true, data: { username: req.admin.username } }));

// ---------- KATEGORIYALAR ----------
const slugify = (s) => s.toLowerCase().replace(/['‘’`]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 120);

router.post('/categories', validate(z.object({ name: z.string().trim().min(1).max(100) })),
  asyncH(async (req, res) => {
    const { rows } = await db.query(
      'INSERT INTO categories(name, slug) VALUES ($1,$2) RETURNING *', [req.body.name, slugify(req.body.name)]);
    res.status(201).json({ success: true, data: rows[0] });
  }));

// ---------- MAHSULOTLAR ----------
const productSchema = z.object({
  name: z.string().trim().min(1).max(200),
  sku: z.string().trim().min(1).max(40).optional(),
  category_id: z.number().int().positive().nullable().optional(),
  price: z.number().int().min(0).max(1_000_000_000),
  old_price: z.number().int().min(0).max(1_000_000_000).nullable().optional(),
  stock: z.number().int().min(0).max(1_000_000).default(0),
  short_description: z.string().max(500).default(''),
  description: z.string().max(10000).default(''),
  specs: z.record(z.string().max(100), z.string().max(300)).default({}),
  is_active: z.boolean().default(true),
});

async function uniqueSlug(base, ignoreId = 0) {
  let slug = slugify(base) || 'mahsulot', n = 1, cand = slug;
  while ((await db.query('SELECT 1 FROM products WHERE slug=$1 AND id<>$2', [cand, ignoreId])).rowCount) cand = `${slug}-${++n}`;
  return cand;
}
async function nextSku() {
  const { rows } = await db.query(`SELECT COALESCE(MAX(NULLIF(regexp_replace(sku,'\\D','','g'),'')::int),0)+1 AS n FROM products WHERE sku ~ '^SI-'`);
  return 'SI-' + String(rows[0].n).padStart(4, '0');
}

router.get('/products', asyncH(async (req, res) => {
  const { rows } = await db.query(
    `SELECT p.id, p.sku, p.slug, p.name, p.price, p.old_price, p.stock, p.is_active, p.is_demo,
            c.name AS category,
            (SELECT url FROM product_images i WHERE i.product_id=p.id ORDER BY i.sort_order,i.id LIMIT 1) AS image
       FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC`);
  res.json({ success: true, data: rows });
}));

router.get('/products/:id(\\d+)', asyncH(async (req, res) => {
  const { rows } = await db.query('SELECT * FROM products WHERE id=$1', [req.params.id]);
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Mahsulot topilmadi' });
  const images = (await db.query('SELECT id,url FROM product_images WHERE product_id=$1 ORDER BY sort_order,id', [req.params.id])).rows;
  res.json({ success: true, data: { ...rows[0], images } });
}));

router.post('/products', validate(productSchema), asyncH(async (req, res) => {
  const b = req.body;
  const sku = b.sku || await nextSku();
  const slug = await uniqueSlug(b.name);
  try {
    const { rows } = await db.query(
      `INSERT INTO products(sku,slug,name,category_id,price,old_price,stock,short_description,description,specs,is_active)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,
      [sku, slug, b.name, b.category_id ?? null, b.price, b.old_price ?? null, b.stock,
       b.short_description, b.description, JSON.stringify(b.specs), b.is_active]);
    res.status(201).json({ success: true, data: rows[0] });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ success: false, error: 'Bu SKU allaqachon mavjud' });
    if (e.code === '23503') return res.status(400).json({ success: false, error: 'Kategoriya topilmadi' });
    throw e;
  }
}));

router.put('/products/:id(\\d+)', validate(productSchema), asyncH(async (req, res) => {
  const b = req.body, id = Number(req.params.id);
  const cur = (await db.query('SELECT sku FROM products WHERE id=$1', [id])).rows[0];
  if (!cur) return res.status(404).json({ success: false, error: 'Mahsulot topilmadi' });
  try {
    const { rows } = await db.query(
      `UPDATE products SET sku=$1, slug=$2, name=$3, category_id=$4, price=$5, old_price=$6, stock=$7,
         short_description=$8, description=$9, specs=$10, is_active=$11, updated_at=now()
       WHERE id=$12 RETURNING *`,
      [b.sku || cur.sku, await uniqueSlug(b.name, id), b.name, b.category_id ?? null, b.price, b.old_price ?? null,
       b.stock, b.short_description, b.description, JSON.stringify(b.specs), b.is_active, id]);
    res.json({ success: true, data: rows[0] });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ success: false, error: 'Bu SKU allaqachon mavjud' });
    if (e.code === '23503') return res.status(400).json({ success: false, error: 'Kategoriya topilmadi' });
    throw e;
  }
}));

router.delete('/products/:id(\\d+)', asyncH(async (req, res) => {
  const imgs = (await db.query('SELECT url FROM product_images WHERE product_id=$1', [req.params.id])).rows;
  const r = await db.query('DELETE FROM products WHERE id=$1', [req.params.id]);
  if (!r.rowCount) return res.status(404).json({ success: false, error: 'Mahsulot topilmadi' });
  imgs.forEach((i) => removeFile(i.url));
  res.json({ success: true });
}));

// ---------- RASM YUKLASH ----------
const uploadDir = path.join(__dirname, 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const EXT = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' };
const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (req, file, cb) => cb(null, crypto.randomBytes(12).toString('hex') + EXT[file.mimetype]),
  }),
  limits: { fileSize: 3 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => EXT[file.mimetype] ? cb(null, true) : cb(new Error('Faqat JPG, PNG yoki WEBP rasm mumkin')),
});
function removeFile(url) {
  const f = path.join(uploadDir, path.basename(url));
  fs.unlink(f, () => {});
}

router.post('/products/:id(\\d+)/images', (req, res, next) => {
  upload.single('image')(req, res, (err) => {
    if (err) return res.status(400).json({ success: false, error: err.code === 'LIMIT_FILE_SIZE' ? 'Rasm 3 MB dan katta bo\'lmasin' : err.message });
    next();
  });
}, asyncH(async (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, error: 'Rasm tanlanmagan' });
  const p = await db.query('SELECT 1 FROM products WHERE id=$1', [req.params.id]);
  if (!p.rowCount) { removeFile(req.file.filename); return res.status(404).json({ success: false, error: 'Mahsulot topilmadi' }); }
  const url = `/uploads/${req.file.filename}`;
  const { rows } = await db.query(
    `INSERT INTO product_images(product_id,url,sort_order)
     VALUES ($1,$2,(SELECT COALESCE(MAX(sort_order),0)+1 FROM product_images WHERE product_id=$1)) RETURNING id,url`,
    [req.params.id, url]);
  res.status(201).json({ success: true, data: rows[0] });
}));

router.delete('/images/:id(\\d+)', asyncH(async (req, res) => {
  const { rows } = await db.query('DELETE FROM product_images WHERE id=$1 RETURNING url', [req.params.id]);
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Rasm topilmadi' });
  removeFile(rows[0].url);
  res.json({ success: true });
}));

router.use('/orders', require('./routes-admin-orders'));

module.exports = router;
