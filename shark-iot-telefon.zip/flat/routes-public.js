const express = require('express');
const { z } = require('zod');
const db = require('./db');
const { asyncH, validate } = require('./middleware');

const router = express.Router();

const listQuery = z.object({
  q: z.string().trim().max(100).optional(),
  category: z.string().trim().max(120).optional(),
  minPrice: z.coerce.number().int().min(0).optional(),
  maxPrice: z.coerce.number().int().min(0).optional(),
  inStock: z.enum(['1', 'true']).optional(),
  sale: z.enum(['1', 'true']).optional(),
  isNew: z.enum(['1', 'true']).optional(),
  sort: z.enum(['price_asc', 'price_desc', 'new', 'popular']).default('new'),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(48).default(12),
});

const SORTS = {
  price_asc: 'p.price ASC, p.id',
  price_desc: 'p.price DESC, p.id',
  new: 'p.created_at DESC, p.id DESC',
  popular: 'p.sold_count DESC, p.id',
};

router.get('/categories', asyncH(async (req, res) => {
  const { rows } = await db.query(
    `SELECT c.id, c.name, c.slug, COUNT(p.id)::int AS product_count
       FROM categories c LEFT JOIN products p ON p.category_id = c.id AND p.is_active
      GROUP BY c.id ORDER BY c.sort_order, c.name`);
  res.json({ success: true, data: rows });
}));

router.get('/products', validate(listQuery, 'query'), asyncH(async (req, res) => {
  const f = req.query;
  const where = ['p.is_active = true'];
  const params = [];
  const add = (v) => { params.push(v); return `$${params.length}`; };

  if (f.q) {
    // har bir so'z bo'yicha qidiradi: "esp32 devkit"
    for (const w of f.q.split(/\s+/).filter(Boolean).slice(0, 5)) {
      const p = add(`%${w.replace(/[%_\\]/g, '\\$&')}%`);
      where.push(`(p.name ILIKE ${p} OR p.sku ILIKE ${p} OR p.short_description ILIKE ${p} OR c.name ILIKE ${p})`);
    }
  }
  if (f.category) where.push(`c.slug = ${add(f.category)}`);
  if (f.minPrice !== undefined) where.push(`p.price >= ${add(f.minPrice)}`);
  if (f.maxPrice !== undefined) where.push(`p.price <= ${add(f.maxPrice)}`);
  if (f.inStock) where.push('p.stock > 0');
  if (f.sale) where.push('p.old_price IS NOT NULL AND p.old_price > p.price');
  if (f.isNew) where.push(`p.created_at > now() - interval '30 days'`);

  const whereSql = where.join(' AND ');
  const base = `FROM products p LEFT JOIN categories c ON c.id = p.category_id WHERE ${whereSql}`;
  const total = (await db.query(`SELECT COUNT(*)::int AS n ${base}`, params)).rows[0].n;

  const offset = (f.page - 1) * f.limit;
  const { rows } = await db.query(
    `SELECT p.id, p.sku, p.slug, p.name, p.price, p.old_price, p.stock, p.short_description,
            p.is_demo, p.created_at, c.name AS category, c.slug AS category_slug,
            (SELECT url FROM product_images i WHERE i.product_id = p.id ORDER BY i.sort_order, i.id LIMIT 1) AS image
       ${base} ORDER BY ${SORTS[f.sort]} LIMIT ${add(f.limit)} OFFSET ${add(offset)}`, params);

  res.set('Cache-Control', 'public, max-age=30');
  res.json({
    success: true,
    data: rows.map((r) => ({ ...r, in_stock: r.stock > 0 })),
    pagination: { page: f.page, limit: f.limit, total, pages: Math.ceil(total / f.limit) },
  });
}));

router.get('/products/:slug', asyncH(async (req, res) => {
  const { rows } = await db.query(
    `SELECT p.id, p.sku, p.slug, p.name, p.price, p.old_price, p.stock, p.short_description,
            p.description, p.specs, p.is_demo, c.name AS category, c.slug AS category_slug
       FROM products p LEFT JOIN categories c ON c.id = p.category_id
      WHERE p.slug = $1 AND p.is_active`, [req.params.slug]);
  if (!rows[0]) return res.status(404).json({ success: false, error: 'Mahsulot topilmadi' });
  const images = (await db.query(
    'SELECT id, url FROM product_images WHERE product_id = $1 ORDER BY sort_order, id', [rows[0].id])).rows;
  res.json({ success: true, data: { ...rows[0], in_stock: rows[0].stock > 0, images } });
}));

module.exports = router;
