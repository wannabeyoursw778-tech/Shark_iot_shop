# SHARK IoT — telefondan joylash (papkasiz versiya)

Bu versiyada hamma fayl bitta qatlamda, shuning uchun GitHub'ga telefondan yuklash oson.

## 0. Zip'ni oching
Telefoningizda "Files" (Fayllar) ilovasi → zip'ni bosing → "Extract" (Chiqarish). 20 ga yaqin fayl chiqadi.

## 1. GitHub'ga yuklash
1. Repository'ni oching → **Add file** → **Upload files**.
2. **choose your files** → ochilgan fayllarning HAMMASINI belgilang (bittasini uzoq bosing, keyin qolganlarini).
3. Pastda **Commit changes**.
Eski `shark-iot-bosqich-2.zip` ni o'chirib tashlang (fayl ichida ⋯ → Delete file).
GitHub Pages kerak emas: Settings → Pages → Unpublish site.

## 2. Database — Neon (neon.tech)
1. Google bilan kiring → Create project (nom: shark-iot).
2. **Connection string** ni nusxalang (`postgresql://...`).

## 3. Server — Render (render.com)
1. New → **Web Service** → GitHub repo'ni tanlang.
2. Root Directory: **bo'sh qoldiring**. Build Command: `npm install`. Start Command: `npm start`. Tarif: Free.
3. Environment Variables:
   - `DATABASE_URL` = Neon'dan nusxalagan matn
   - `JWT_SECRET` = 40+ belgili tasodifiy matn (klaviaturada harf va raqam aralash yozing)
   - `NODE_ENV` = `production`
   - `FRONTEND_URL` = Render bergan manzil
   - `ADMIN_USER` = admin login
   - `ADMIN_PASS` = parol (kamida 10 belgi)
   - `SEED_DEMO` = `true`
4. **Create Web Service**. 3–5 daqiqadan keyin `https://....onrender.com` ochiladi.

## Eslatma
- Bepul Render uxlab qoladi, birinchi ochilish 30–50 soniya olishi mumkin.
- Rasmlar bepul tarifda qayta ishga tushganda o'chadi (doimiy saqlash keyin ulanadi).
- Parolni hech kimga bermang, GitHub'ga yozmang.
